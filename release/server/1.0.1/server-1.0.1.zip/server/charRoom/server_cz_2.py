from livestreaming import settings
from protobuf import message_pb2
from enum import Enum
import asyncio

# room_list is a dict whose key is room name and value is a dict
# the latter dict's key is username and its value is user's writer
room_list = [{'Dux': {}}]
server_loop = None


class MsgType(Enum):
    LEAVE = 0
    ENTER = 1
    CHAT = 2
    CREATE = 3
    UNUSUAL = 4


def leave(room_name, user_name, cdlp_message):
    for room in room_list:
        if room_name in room:
            del room[room_name][user_name]
            for writer_object in list(room[room_name].values()):
                writer_object.write(cdlp_message.SerializeToString())


def enter(writer, room_name, user_name, cdlp_message):
    for room in room_list:
        if room_name in room:
            room[room_name][user_name] = writer
            for writer_object in list(room[room_name].values()):
                writer_object.write(cdlp_message.SerializeToString())


def chat(room_name, cdlp_message):
    for room in room_list:
        if room_name in room:
            for writer_object in list(room[room_name].values()):
                writer_object.write(cdlp_message.SerializeToString())


def create_room(room_name):
    room_list.append({room_name: {}})


def unusual_status_change(room_name, cdlp_message):
    for room in room_list:
        if room_name in room:
            # send the message to all the users in the room
            for writer_object in list(room[room_name].values()):
                writer_object.write(cdlp_message.SerializeToString())


async def service(reader, writer):
    while server_loop.is_closed() is False:
        # receive protobuf binary message
        data = await reader.read(1024)
        data += await reader.read(1024)
        if data == b'':
            continue
        # deserialize protobuf binary message
        cdlp_message = message_pb2.CdlpMessage()
        cdlp_message.ParseFromString(data)
        # anchor name is equivalent to room name
        room_name = cdlp_message.anchorName
        user_name = cdlp_message.userName
        msg_type = cdlp_message.type
        print(cdlp_message)

        if msg_type == MsgType.LEAVE.value:
            leave(room_name, user_name, cdlp_message)
        elif msg_type == MsgType.ENTER.value:
            enter(writer, room_name, user_name, cdlp_message)
        elif msg_type == MsgType.CHAT.value:
            chat(room_name, cdlp_message)
        elif msg_type == MsgType.CREATE.value:
            create_room(room_name)
        elif msg_type == MsgType.UNUSUAL.value:
            unusual_status_change(room_name, cdlp_message)


if __name__ == '__main__':
    server_loop = asyncio.get_event_loop()
    server_loop_procedure = asyncio.start_server(service, settings.SOCKET_HOST_IP, settings.SOCKET_HOST_PORT,
                                                 loop=server_loop)
    server_loop.run_until_complete(server_loop_procedure)
    server_loop.run_forever()
