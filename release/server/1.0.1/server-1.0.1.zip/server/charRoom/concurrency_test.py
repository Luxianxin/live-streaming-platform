from protobuf import message_pb2
import socket, random, time


async def new_request():
    msg = message_pb2.CdlpMessage()
    msg.type = random.randint(0, 3)
    msg.chat = 'fuck you'
    msg.userName = 'cz'
    msg.level = 5
    msg.anchorName = 'pp'

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(('192.168.1.71', 8001))
    sock.send(msg.SerializeToString())


async def main():
    await new_request()


if __name__ == '__main__':
    # current_concurrency = 0
    # while True:
    #     main()
    #     current_concurrency += 1
    #     print(current_concurrency)
    #     time.sleep(1)
    msg = message_pb2.CdlpMessage()
    msg.type = random.randint(0, 3)
    msg.chat = 'fuck you'
    msg.userName = 'cz'
    msg.level = 5
    msg.anchorName = 'pp'

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(('192.168.1.71', 8001))
    sock.send(msg.SerializeToString())
