# -*- coding: utf-8 -*-
import socket
import select
import threading
from time import sleep
import message_pb2 as message

# format of send message
sendMessage = message.CdlpMessage()
recvMessage = message.CdlpMessage()
sendMessage.userName = 'aaa'
sendMessage.level = 0
sendMessage.type = 1
sendMessage.anchorName = 'bbb'

def startClient():
    # connect to server
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(('127.0.0.1', 8000))
    socketLock = threading.Lock()

    # receive thread
    def readThreadMethod():
        while True:
            if not sock:
                break
            rs, _, _ = select.select([sock], [], [], 10)
            for r in rs:
                socketLock.acquire()

                if not sock:
                    socketLock.release()
                    break

                data = r.recv(1024)
                recvMessage.ParseFromString(data)
                print(recvMessage.chat)
                socketLock.release()

                if not data:
                    print('server close')

    readThread = threading.Thread(target=readThreadMethod)
    readThread.setDaemon(True)
    readThread.start()

    # keep sending messages
    # input message type first
    while True:
        sleep(.5)
        type = input("> ")
        sendMessage.type = int(type)
        if type == '0':
            sendMessage.chat = 'Leave Room'
        if type == '1':
            sendMessage.chat = 'Enter Room'
        if type == '2':
            data = input("> ")
            sendMessage.chat = data
        serializeMessage = sendMessage.SerializeToString()
        sock.send(serializeMessage)

    # close charRoom
    socketLock.acquire()
    sock.close()
    sock = None
    socketLock.release()

if __name__ == "__main__":
    startClient()
