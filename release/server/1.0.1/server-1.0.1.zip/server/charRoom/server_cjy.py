#!/usr/bin/python
# -*- coding: UTF-8 -*-

from protobuf import message_pb2 as message
import socket
import _thread
import select
from time import ctime


# ========== Class ServerSocket ===============#
class ServerSocket:
    def __init__(self, serverSocket):
        self.sock = serverSocket
        self.clientList = {}

    # Recv thread
    def recv(self):
        self.sock.listen(5)
        receiveList = []
        receiveList.append(self.sock)

        while True:
            cliSock, cliAddr = self.sock.accept()
            print("connected from :", cliAddr)
            while True:
                recvMessage = message.CdlpMessage()
                data = cliSock.recv(1024)

                recvMessage.ParseFromString(data)

                if recvMessage.type == 1:
                    print('enter room')
                    print(recvMessage.username, recvMessage.level, recvMessage.type, recvMessage.anchorName)
                    # cliSock.send(data)
                elif recvMessage.type == 2:
                    print(recvMessage.chat)
                    cliSock.send(data)
                elif recvMessage.type == 0:
                    print('leave room')
                # else:
                #    print('receive data error')

            '''
            if recvMessage.type == 0:
                self.clientList.remove((cliSock,cliAddr))

            elif recvMessage.type == 1:
                #self.clientList.append((cliSock,cliAddr))
                if self.clientList.get(recvMessage.anchorName, default=None)!='None':
                    self.clientList[recvMessage.anchorName].append(recvMessage.username)
                    print(self.clientList.get(recvMessage.anchorName))
                else:
                    newKeyValue = {recvMessage.anchorName:[recvMessage.username]}
                    self.clientList.update(newKeyValue)
                    print(self.clientList)

            elif recvMessage.type == 2:
                for client in self.clientList:
                    client.send(data)
                #cliSock.send(data)
            
            else:
                print('receive data error')
            '''


# Main function
if __name__ == '__main__':
    serverHost = '127.0.0.1'
    serverPort = 8082
    serverAddr = (serverHost, serverPort)
    serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serverSocket.bind(serverAddr)

    try:
        _thread.start_new_thread(ServerSocket(serverSocket).recv, (), )
    except:
        print("Error: unable to start thread")
    try:
        while 1:
            pass

    except:
        serverSocket.close()
        print("***** Finished! ******")
