from django.apps import AppConfig


class StreamingroomConfig(AppConfig):
    name = 'streamingRoom'
