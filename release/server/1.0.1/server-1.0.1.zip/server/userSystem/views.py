from django.http import HttpResponse
from userSystem import models
import json
